<h1>
    Welcome to uhyggelig site hehe</h1>
    <h2>We are using the nginx so you cannot hack us </h2>
Here you can visit out uhyggelig ghosts.
<br><a href="./file.php?file=florian.txt">Florian<a>
<br><a href="./file.php?file=filipogcristiano.txt">Filip & Cristiano<a>
<br><a href="./file.php?file=jacob.txt">Jacob<a>
<br><a href="./file.php?file=emil.txt">Emil<a>
<br><a href="./file.php?file=hans.txt">Hans<a>